﻿  select distinct eca.examdate, eca.examinationslot,
    ec.examcentername,ec.examcentercode,fc.floorname,cr.classroomname,c.coursecode,
    c.coursename, s.civilid,
    (case when seca.isabsent=true then 'Absent' else 'Present' end)
    as PresentorAbsent,
    (case when seca.isumc=true then 'UMC' else '' end) as UMC
    from affiliation_examcenterattendance eca,
    affiliation_studentexamcenterattendance seca,
    affiliation_classroomcreation cr, affiliation_floorcreation fc,
    univ_exam_examcenter ec,
    courses_course c, student_student s
    where eca.examcenterattendanceid = seca.examcenterattendanceid
    and eca.courseid = c.courseid
    and eca.examcenterid = ec.examcenterid
    and seca.classroomcreationid = cr.classroomcreationid
    and cr.floorcreationid = fc.floorcreationid
    and seca.floorcreationid = fc.floorcreationid
    and seca.floorcreationid = cr.floorcreationid
    and seca.studentid = s.studentid
    and  eca.examdate>=to_date('25-05-2023' , 'dd/MM/yyyy') and eca.examdate<=to_date('07-006-2023' , 'dd/MM/yyyy') 
   -- and eca.companyid=109701