﻿select
  distinct cc.courseid,
  sr.reappearregistrationid,
  sps.studentid,
  cc.coursename,
  cc.coursecode,
  cc.referencenumber,
  cc.newpaperid,
  ss.civilid,
  sps.reappearyear,
  sr.semesterid,
  ac.collegename,
  cp.nameoftheprogram,
  sps.studentid,
  scp.coursecompletionstatus,
  gp.courseid,
  sub.courseid,
  sps.applieddate,
  sps.modifieddate,
  sps.createdate as sps_createdate,
  sr.createdate as sr_createdate,
  ma.externaltheorytotalmarks,
  ma.internaltheorytotalmarks,
  ma.externalpracticaltotalmarks,
  ma.internalpracticaltotalmarks
from
  student_progression_studentprogressionreappearsubjectsregistrat sr
  join student_progression_studentprogressionreappearregistration sps on sps.reappearregistrationid = sr.reappearregistrationid
  join student_student ss on ss.studentid = sps.studentid
  join courses_course cc on cc.courseid = sr.courseid
  join affiliation_college ac on ac.generatedinstituteid = ss.institutename
  join courses_program cp on cp.programid = ss.program
  join univ_exam_marksbreakup ma on ma.courseid=cc.courseid
  join student_progression_courseprogression scp on scp.courseid = sr.courseid
  and ss.studentid = scp.studentid
  left join univ_exam_groupcourse gp on gp.courseid = scp.courseid
  left join univ_exam_groupsubcourse sub on sub.courseid = scp.courseid
where
    sps.reappearyear = 2024
  --sps.applieddate >= '2023-04-01'
  --and sr.createdate <= '2023-05-03' --and ss.civilid = '211060080030'
  and sr.status = 'Approved'
  and sps.paymentstatus = 'Success'
order by
  sps.studentid


select * from student_progression_studentprogressionreappearsubjectsregistrat limit 10
select * from univ_exam_marksbreakup limit 10