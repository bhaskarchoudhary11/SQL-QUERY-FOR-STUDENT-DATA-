﻿   SELECT
distinct ac.collegename as "College Name", p.programcode as "Program Code", p.nameoftheprogram as "Program Name",
c.coursecode as "Subject Code", c.referencenumber as "Subject Object ID", c.coursename AS "Subject Name",lv.valuename,
count(c.courseid),  pm.status as "Locked?", pm.reappearexternaltheorymarkid,
(CASE WHEN (select sum(sit.newobtainedmarks) from univ_exam_studentreappearexternaltheorymarks sit where sit.reappearexternaltheorymarkid = pm.reappearexternaltheorymarkid group by sit.reappearexternaltheorymarkid)>0 and
(select civilid from student_student where studentid in (select studentid from univ_exam_studentreappearexternaltheorymarks where reappearexternaltheorymarkid = pm.reappearexternaltheorymarkid limit 1)
and institutename=iwp.instituteid )::BIGINT>0 THEN 'Entered' ELSE 'Not Entered' END)  as "Marks Entered?",civilid,sre.newobtainedmarks



FROM
courses_institutewiseprogram iwp
INNER JOIN courses_program p ON iwp.programid=p.programid
INNER JOIN affiliation_college ac ON ac.generatedinstituteid = iwp.instituteid
INNER JOIN courses_semesterintakeyear siy ON siy.institutewiseprogramid = iwp.institutewiseprogramid
INNER JOIN courses_semesterintakeyearcourse siyc ON siyc.semesterintakeyearid = siy.semesterintakeyearid
INNER JOIN univ_exam_marksbreakup mb
on mb.academicyear=siy.academicyear AND mb.year=siy.programyear AND mb.semesterid = siy.semesterid AND mb.courseid = siyc.courseid
INNER JOIN courses_course c ON c.courseid = siyc.courseid
INNER JOIN master_lookupvalue lv ON lv.id_ = c.coursecategory
join student_progression_studentprogressionreappearsubjectsregistrat rsub on rsub.courseid=siyc.courseid and
rsub.examtype = (select cast(id_ as varchar(255))from master_lookupvalue where valuecode = 'TH') and rsub.status = 'Approved'
and rsub.semesterid = siy.semesterid
join student_progression_studentprogressionreappearregistration rreg on rreg.reappearregistrationid = rsub.reappearregistrationid
and rreg.paymentstatus ='Success'
left JOIN univ_exam_reappearexternaltheorymark pm ON
pm.academicyear=siy.academicyear AND pm.year=siy.programyear AND pm.semesterid = siy.semesterid AND pm.courseid = c.courseid
INNER JOIN student_progression_courseprogression cp ON  cp.studentid=rreg.studentid and cp.courseid=rsub.courseid
inner join student_student ss on ss.studentid=rreg.studentid
left join univ_exam_studentreappearexternaltheorymarks sre on sre.reappearexternaltheorymarkid= pm.reappearexternaltheorymarkid and sre.studentid=rreg.studentid 
WHERE
(REPLACE(siy.academicyear, ' ', ''))='2019-2020' and siy.programyear =3 and siy.semesterid=6
and cp.active_=true
and  (select count(studentid) from student_student where studentid in(select studentid from  student_progression_courseprogression where courseid =  siyc.courseid and semesterintakeyearid=siy.semesterintakeyearid))>0
and lv.valuename in ('Theory', 'Both')
and mb.externaltheorytotalmarks>0
AND cp.courseprogressionstatus !='Registered'
AND rreg.reappearyear=2023

GROUP BY
ac.collegename , p.programcode , p.nameoftheprogram , c.coursecode , c.referencenumber , c.coursename,lv.valuename, pm.status, pm.reappearexternaltheorymarkid,iwp.instituteid,civilid,sre.newobtainedmarks
ORDER BY ac.collegename, p.nameoftheprogram , c.coursename

