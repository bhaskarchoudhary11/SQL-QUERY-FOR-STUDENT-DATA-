﻿select nameoftheprogram from courses_program 



select distinct ac.collegename,cp.nameoftheprogram,tm.academicyear,tm.year,tm.semesterid,tm.courseid,cc.coursename,cc.coursecode,cc.referencenumber,

ss.intakeyear,ss.civilid,ss.fullname,stm.resultcategory


from univ_exam_studentexternaltheorymarks stm join univ_exam_externaltheorymark tm on tm.externaltheorymarkid=stm.externaltheorymarkid

join courses_course cc on cc.courseid=tm.courseid

join student_student ss on ss.studentid=stm.studentid 

join affiliation_college ac on ac.generatedinstituteid=ss.institutename

join courses_program cp on cp.programid=ss.program

where resultcategory='RLA' and ss.isactive=true 

--and tm.semesterid in (1,3,5)