﻿select ac.collegename,cp.nameoftheprogram,ss.studentidcardno,ss.civilid,ss.fullname
from student_student ss
join courses_program cp on cp.programid=ss.program
join affiliation_college ac on ac.generatedinstituteid=ss.institutename
where urngenerated =false and intakeyear=2022