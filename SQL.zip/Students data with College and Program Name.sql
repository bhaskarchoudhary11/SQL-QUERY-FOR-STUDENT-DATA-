﻿select ac.collegename,cp.nameoftheprogram, ss.intakeyear,ss.civilid,ss.studentidcardno,ss.fullname,ss.aadhaarnumber,ss.dateofbirth,lv.valuename,amq.quotaname,sa.mobile ,ss.intakeyear,cp.typeoftheprogram from student_student ss 
join courses_program cp on cp.programid = ss.program
join master_lookupvalue lv on lv.id_=ss.gender
join admission_management_quota amq on amq.quotaid=ss.quotaid
join student_studentcurrentaddress sa on sa.studentid = ss.studentid
join affiliation_college ac on ac.generatedinstituteid= ss.institutename
where ss.intakeyear in (2019,2020,2021,2022) 
limit 10

select * from courses_program  


select * from student_student limit 10  
select * from student_studentcurrentaddress  limit 10  

select * from master_lookupvalue where id_ = 11  limit 10  
select * from c where id_ = 11

select * from affiliation_college limit 10
select * from admission_management_quota limit 10

select * from courses_program 

1.                   Name of student

2.                   Date of Birth

3.                   Gender

4.                   Aadhar Number

5.                   Mobile No.

6.                   Regn No.

7.                   Roll No.