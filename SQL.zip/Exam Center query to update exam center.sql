﻿select examcenterid,examcentercode from univ_exam_examcenter where examcentercode in ('2301_May 23',
'2312_May 23',
'2306_May 23',
'2307_May 23',
'2305_May 23',
'2302_May 23',
'2303_May 23',
'2304_May 23',
'2308_May 23',
'2309_May 23',
'2310_May 23',
'2319_May 23',
'2311_May 23',
'2313_May 23',
'2314_May 23',
'2321_May 23',
'2318_May 23',
'2315_May 23',
'2316_May 23',
'2317_May 23')
select * from univ_exam_examcenter where examcenterid  =70

select * from student_student where civilid in ('191030050019')
select * from univ_exam_studentexamcenter where studentid  =11049 and academicyear='2019-2020' and reappearyear=2024 and reappearmonth='May'
update univ_exam_studentexamcenter set examcenterid =? where academicyear='2019-2020' and reappearyear=2024 and reappearmonth='May' and studentid=?


select se.studentexamcenterid,se.studentid,ss.civilid,cp.nameoftheprogram,ac.collegename,se.academicyear,se.year,se.semesterid,se.examcenterid,ec.examcentercode,se.reappearyear,se.reappearmonth from univ_exam_studentexamcenter se
join univ_exam_examcenter ec on ec.examcenterid=se.examcenterid
join student_student ss on ss.studentid=se.studentid
join courses_program cp on cp.programid=ss.program
join affiliation_college ac on ac.generatedinstituteid=ss.institutename
where forreappear= False and academicyear = '2022-2023' and semesterid = 2 --and reappearmonth = 'May' sc

select * from univ_exam_studentexamcenter limit 10

