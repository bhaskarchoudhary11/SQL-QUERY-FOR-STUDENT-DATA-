﻿select
  o.name,
  p.nameoftheprogram,
  et.academicyear,
  et.year,
  s.civilid,
  sem.semestername,
  c.coursecode,
  c.coursename,
  c.referencenumber,
  se.studentexternaltheorymarksid,
  se.studentid,
  se.obtainedmarks,
  se.processedobtainedmarks
from
  univ_exam_studentexternaltheorymarks se
  join univ_exam_externaltheorymark et on et.externaltheorymarkid = se.externaltheorymarkid
  join courses_course c on c.courseid = et.courseid
  join student_student s on s.studentid = se.studentid
  join organization_ o on o.organizationid = s.institutename
  join courses_program p on p.programid = s.program
  join courses_semester sem on sem.semesterid = et.semesterid
where
  se.studentexternaltheorymarksid in (
    select
      studentexternaltheorymarksid
    from
      univ_exam_studentreappearexternaltheorymarks
    where
      reappearexternaltheorymarkid in (
        select
          reappearexternaltheorymarkid
        from
          univ_exam_reappearexternaltheorymark
        where
          academicyear = '2019-2020'
          and year = 1
          and semesterid = 1
          and reappearyear = 2023
      )
      and newobtainedmarks = 0
      and answersheetnumber = ''
  )
