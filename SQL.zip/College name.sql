﻿SELECT * from courses_program limit 1

select distinct cp.nameoftheprogram,cp.programcode, ss.intakeyear from student_student ss
join courses_program cp on cp.programid = ss.program


select distinct ac.collegename from student_student ss
join affiliation_college ac on ac.generatedinstituteid = ss.institutename



select * from student_student limit 1



select * from affiliation_college limit 1