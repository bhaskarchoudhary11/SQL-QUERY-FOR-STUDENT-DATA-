﻿select * from univ_exam_examtimetable limit 10
join courses_course cc on cccoureseid=uee.coureseid

limit 10



select * from univ_exam_examtimetable limit 2
select * from courses_semesterintakeyearcourse limit 2

 


select ex.examtimetableid,cp.nameoftheprogram,ex.academicyear,ex.year,ex.semesterid,cc.coursename,cc.coursecode,cc.coursedescription,cc.referencenumber,cc.newpaperid,ex.examdate,ex.starttime,ex.endtime,ex.createddate,ex.courseexamtype,ex.reappearyear
from univ_exam_examtimetable ex
join courses_course cc on cc.courseid=ex.courseid
join courses_semesterintakeyearcourse sc on sc.courseid=ex.courseid
join courses_program cp on cp.programid=sc.programid
where ex.createddate > '2023-05-11' and ex.courseexamtype = 'Theory'