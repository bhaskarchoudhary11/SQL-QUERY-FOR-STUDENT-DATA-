--------------------------------------------re-evalution.sql  with published and exam month

select ss.fullname,ss.civilid,ss.studentidcardno,ssp.transactionnumber,ssp.paymentstatus,cp.nameoftheprogram,ssp.academicyear,ssp.semesterid,cc.coursename,cc.coursecode,cc.referencenumber,cc.coursedescription,
ssp.transactiondate,spc.overallcoursemark,stu.obtainedmarks,stu.answerbookreferencenumber,sp.markprocessstatus,sem.semesterexammonthyear
from student_studentservicepaymentrequest ssp  
join student_student ss on ss.studentid = ssp.studentid
join courses_program cp on cp.programid= ss.program
join student_studentservicepaymentsubjectmapping ssps on ssps.studentservicepaymentrequestid=ssp.studentservicepaymentrequestid
join courses_course cc on cc.courseid=ssps.subjectid
inner join student_progression_semesterprogression sp on sp.studentid = ss.studentid and sp.semesterid = ssp.semesterid and sp.markprocessstatus='Published'
inner join univ_exam_semesterexammonthyear sem on sem.semesterexammonthyearid = sp.semesterexammonthyearid
left join student_progression_courseprogression spc on spc.courseid=ssps.subjectid and spc.studentid=ssp.studentid
left join univ_exam_externaltheorymark ex on ex.courseid=ssps.subjectid and ex.semesterid=spc.semester
left join univ_exam_studentexternaltheorymarks stu on stu.externaltheorymarkid=ex.externaltheorymarkid and stu.studentid=ss.studentid
where ssp.servicerequesttypeid=667 and ssp.paymentstatus='Success' and transactiondate > '2023-06-27 00:00:00'

-----------------------------------------Rechecking.sql with published and exam month
select ss.fullname,ss.civilid,ss.studentidcardno,ssp.transactionnumber,ssp.paymentstatus,cp.nameoftheprogram,ssp.academicyear,ssp.semesterid,cc.coursename,cc.coursecode,cc.referencenumber,cc.coursedescription,
ssp.transactiondate,spc.overallcoursemark,stu.obtainedmarks,stu.answerbookreferencenumber,sp.markprocessstatus,sem.semesterexammonthyear
from student_studentservicepaymentrequest ssp  
join student_student ss on ss.studentid = ssp.studentid
join courses_program cp on cp.programid= ssp.programid
join student_studentservicepaymentsubjectmapping ssps on ssps.studentservicepaymentrequestid=ssp.studentservicepaymentrequestid
join courses_course cc on cc.courseid=ssps.subjectid
inner join student_progression_semesterprogression sp on sp.studentid = ss.studentid and sp.semesterid = ssp.semesterid and sp.markprocessstatus='Published'
inner join univ_exam_semesterexammonthyear sem on sem.semesterexammonthyearid = sp.semesterexammonthyearid
left join student_progression_courseprogression spc on spc.courseid=ssps.subjectid and spc.studentid=ssp.studentid
left join univ_exam_externaltheorymark ex on ex.courseid=ssps.subjectid and ex.semesterid=spc.semester
left join univ_exam_studentexternaltheorymarks stu on stu.externaltheorymarkid=ex.externaltheorymarkid and stu.studentid=ss.studentid
where ssp.servicerequesttypeid=668 and ssp.paymentstatus='Success' and transactiondate > '2023-06-27 00:00:00'