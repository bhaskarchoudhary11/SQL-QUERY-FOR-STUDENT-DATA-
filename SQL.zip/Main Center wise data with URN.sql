﻿SELECT
  ec.examcentercode,
  ec.examcentername,
  et.examdate,
  et.starttime,
  et.endtime,
  et.examinationslot,
  cc.coursecode,
  cc.coursename,
  cc.referencenumber,
  sec.studentid,
  st.civilid
FROM
  univ_exam_examtimetable et
  JOIN student_progression_courseprogression cp ON et.courseid = cp.courseid
  JOIN univ_exam_studentexamcenter sec ON sec.studentid = cp.studentid
  JOIN univ_exam_examcenter ec ON sec.examcenterid = ec.examcenterid
  JOIN courses_course cc ON cc.courseid = cp.courseid
  JOIN student_student st ON st.studentid = sec.studentid
WHERE
  et.examdate BETWEEN '2023-05-25'
  AND '2023-07-31'
  and et.isreappear = false
  AND et.semesterid = sec.semesterid
  AND et.academicyear = sec.academicyear
  AND sec.examcenterid = ec.examcenterid
  AND cp.semester = sec.semesterid
ORDER BY
  et.examdate,
  et.examinationslot,
  cc.coursecode,
  cc.coursename,
  cc.referencenumber
  
