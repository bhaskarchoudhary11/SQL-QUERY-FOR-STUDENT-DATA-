﻿select o.name as "Allocated College Name",p.nameoftheprogram as "Program Name",q.quotaname as "Applied Quota",app.applicationnumber,ap.fullname
,g.fullname as "Father Name",ppp.newfamilyid,aaa.intakeyear,ag.annualincome,ac.aadharnumber,ac.uniqueidentificationnumber,ac.passportnumber,app.applicationstatus,
app.submitteddate,ap.gender,ap.mobilenumber,ap.email,addr.addressline1,addr.addressline2,addr.addressline3,addr.city,ap.dateofbirth,ad.documenturl
from admission_management_application app
join courses_program p on p.programid = app.appliedprogramid and app.applicationstatus=2
join admission_management_applicant ap on ap.applicantid=app.applicantid
left join admission_management_quota q on q.quotaid=app.quotaid
left join admission_management_applicantpppdetails ppp on ppp.applicantid=app.applicantid
left join organization_ o on o.organizationid = app.preferedinstituteid
left join admission_management_guardian g on g.applicantid=ap.applicantid and guardiantype='Father'
join admission_management_admissionconfiguration aaa on aaa.programid=app.appliedprogramid and aaa.admissionconfigurationid=app.admissionconfigurationid
left join  admission_management_guardian ag on ag.applicantid =app.applicantid and ag.guardiantype ='Father'
left join admission_management_citizenship ac on ac.applicantid =app.applicantid
left join admission_management_applicationdocuments ad on ad.applicationid=app.applicationid and ad.documenttype='photo'
join admission_management_address addr on addr.addressid=ap.currentaddressid
 order by aaa.intakeyear,app.appliedprogramid