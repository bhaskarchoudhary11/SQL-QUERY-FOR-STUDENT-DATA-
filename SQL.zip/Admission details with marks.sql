﻿select applicationnumber,ap.applicationid,ap.applicantid,fullname,nameoftheprogram,to_char(dateofbirth,'dd-mm-yyyy'),(select fullname from admission_management_guardian
  where guardiantype ='Father' and applicantid=ap.applicantid limit 1),quotaname,(
select examtypeid from admission_management_academicinformation
where applicantid=ap.applicantid and examtypeid in (select qualifiedexamid from
admission_management_meritcalculationcriteria
where admissionconfigurationid =ap.admissionconfigurationid) order by cast(obtainedcreditsormarkspercentage as decimal(10,4)) desc limit 1),(
select obtainedcreditsormarks from admission_management_academicinformation
where applicantid=ap.applicantid and examtypeid in (select qualifiedexamid from
admission_management_meritcalculationcriteria
where admissionconfigurationid =ap.admissionconfigurationid) order by cast(obtainedcreditsormarkspercentage as decimal(10,4)) desc limit 1),(
select maxcreditsormarks from admission_management_academicinformation
where applicantid=ap.applicantid and examtypeid in (select qualifiedexamid from
admission_management_meritcalculationcriteria
where admissionconfigurationid =ap.admissionconfigurationid) order by cast(obtainedcreditsormarkspercentage as decimal(10,4)) desc limit 1),
(select obtainedcreditsormarkspercentage from admission_management_academicinformation
where applicantid=ap.applicantid and examtypeid in (select qualifiedexamid from
admission_management_meritcalculationcriteria
where admissionconfigurationid =ap.admissionconfigurationid) order by cast(obtainedcreditsormarkspercentage as decimal(10,4)) desc limit 1),

 

 

(select (case when isqualifyingexamfromharyana=true then 'yes' else 'no' end) from admission_management_affilatedcollegeapplicationdetail where applicationid=ap.applicationid )Q1,
(select (case when  isrecipientsncert=true then 'yes' else 'no' end) from admission_management_affilatedcollegeapplicationdetail  where applicationid=ap.applicationid )Q2,
(select (case when  isconsistentlygoodrecord=true then 'yes' else 'no' end)  from admission_management_affilatedcollegeapplicationdetail  where applicationid=ap.applicationid )Q3,
(select  (case when  ispassedhonoursexamination=true then 'yes' else 'no' end)  from admission_management_affilatedcollegeapplicationdetail  where applicationid=ap.applicationid )Q4,
(select (case when  ispassedncccadets=true then 'yes' else 'no' end)   from admission_management_affilatedcollegeapplicationdetail  where applicationid=ap.applicationid )Q5
,weightagemark,applicationverificationstatus,
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=1),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=2),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=3),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=4),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=5),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=6),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=7),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=8),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=9),
(select name from admission_management_preferdaffilatedcollege pc inner join organization_ o on o.organizationid=pc.instituteid where applicationid =ap.applicationid and preferedcollegeorder=10)

 


from admission_management_application ap join
admission_management_applicant app on ap.applicantid=app.applicantid
join admission_management_quota qo on qo.quotaid=ap.quotaid
join admission_management_admissionconfiguration ac on ac.admissionconfigurationid=ap.admissionconfigurationid
join courses_program cp on cp.programid=ac.programid
where applicationstatus=2 and intakeyear=2023 and  typeoftheprogram not in('Ph.D.')
order by applicationnumber,nameoftheprogram,applicationverificationstatus