﻿--Main Exam Processing Status Query:
select distinct csi.academicyear,year,semestername,nameoftheprogram,status From courses_institutewiseprogram cip join courses_semesterintakeyear csi on cip.institutewiseprogramid=csi.institutewiseprogramid
left join univ_exam_marksprocess ump on csi.academicyear=ump.academicyear and csi.programyear=ump.year and csi.semesterid=ump.semesterid and cip.programid=ump.programid
join courses_program cp on cp.programid=cip.programid

join courses_semester cs on cs.semesterid=csi.semesterid
 where  csi.academicyear ='2022-2023' and csi.semesterid=2 and csi.programyear=1
 order by csi.academicyear,year,semestername,nameoftheprogram,status


--Reappear Exam Processing Status Query:

select distinct csi.academicyear,year,semestername,nameoftheprogram,status,reappearyear From courses_institutewiseprogram cip join courses_semesterintakeyear csi on cip.institutewiseprogramid=csi.institutewiseprogramid
left join univ_exam_marksprocess ump on csi.academicyear=ump.academicyear and csi.programyear=ump.year and csi.semesterid=ump.semesterid and cip.programid=ump.programid
left join univ_exam_marksprocessreappearyearmapping umpr on umpr.marksprocessid=ump.marksprocessid
join courses_program cp on cp.programid=cip.programid
join courses_semester cs on cs.semesterid=csi.semesterid where reappearyear=2024
 order by csi.academicyear,year,semestername,nameoftheprogram,status,reappearyear 



select * from univ_exam_marksprocessreappearyearmapping