﻿select p.nameoftheprogram,count(applicationid) from admission_management_application app
join admission_management_admissionconfiguration ac on ac.admissionconfigurationid=app.admissionconfigurationid
join courses_program p on p.programid=ac.programid
 where applicationstatus = 2 and intakeyear=2022
 group by p.nameoftheprogram


select * from admission_management_admissionconfiguration  limit 10 where admissionconfigurationid 


select * from admission_management_application app
join admission_management_admissionconfiguration ac on ac.admissionconfigurationid=app.admissionconfigurationid
join courses_program p on p.programid=ac.programid
 where applicationstatus = 2 and intakeyear=2022 and ac.programid=129
 group by p.programid