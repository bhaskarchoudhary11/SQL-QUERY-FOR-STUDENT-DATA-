﻿select * from student_student where studentid =


select * from univ_exam_migrationcertificate 