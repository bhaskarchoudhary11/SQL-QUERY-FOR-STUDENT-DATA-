﻿select c.collegename,p.nameoftheprogram,s.intakeyear,sem.semestername,s.civilid,s.studentidcardno,cc.coursedescription,
cc.coursecode,cc.referencenumber,cc.coursename,cp.createdate,mlv.valuename,uem.externaltheorytotalmarks,uem.internaltheorytotalmarks,uem.externalpracticaltotalmarks,uem.internalpracticaltotalmarks from student_progression_courseprogression cp
join student_student s on s.studentid=cp.studentid
join courses_course cc on cc.courseid=cp.courseid
join master_lookupvalue mlv on mlv.id_ = cc.coursecategory
join courses_semester sem on sem.semesterid=cp.semester
join univ_exam_marksbreakup uem on uem.courseid = cc.courseid
join courses_program p on p.programid=cp.programid
join affiliation_college c on c.generatedinstituteid=s.institutename
where semestername in ('Semester 2', 'Semester 4','Semester 6','Semester 8') and s.isactive = True and cc.referencenumber ='10386' --and date(cp.createdate) >= date('2023-04-01') and s.isactive = True and cc.referencenumber ='10386'
order by c.collegename,p.nameoftheprogram,s.intakeyear,sem.semestername,s.civilid,s.studentidcardno,cc.coursecode,
cc.referencenumber,cc.coursename,cp.createdate,mlv.valuename
limit 10

select * from student_progression_courseprogression limit 10

select * from courses_course limit 10

select * from master_lookupvalue 

select * from univ_exam_marksbreakup limit 10