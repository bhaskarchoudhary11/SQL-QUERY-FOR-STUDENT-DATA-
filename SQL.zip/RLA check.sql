﻿select cp.nameoftheprogram,ac.collegename,ss.civilid,ss.fullname,cc.coursecode,cc.coursename,cc.referencenumber,etm.academicyear,etm.year,etm.semesterid,hh.obtainedmarks,hh.answerbookreferencenumber,hh.processedobtainedmarks,hh.publishedobtainedmarks,hh.resultcategory from univ_exam_studentexternaltheorymarks hh
join student_student ss on ss.studentid=hh.studentid
join univ_exam_externaltheorymark etm on etm.externaltheorymarkid=hh.externaltheorymarkid
join courses_course cc on cc.courseid=etm.courseid
join courses_program cp on cp.programid=ss.program
join affiliation_college ac on ac.generatedinstituteid=ss.institutename
where hh.obtainedmarks = 0 and hh.answerbookreferencenumber='' and hh.resultcategory='None' and etm.academicyear='2020-2021' and etm.semesterid = 5



select * from student_student limit 10