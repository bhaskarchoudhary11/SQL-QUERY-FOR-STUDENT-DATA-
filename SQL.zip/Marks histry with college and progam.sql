﻿select * from univ_exam_studentexternaltheorymarks where studentid = 53981

--4751

select * from univ_exam_externaltheorymark limit 1

select * from univ_exam_studentexternaltheorymarkshistory where studentid = 11103 and externaltheorymarkid = 4277



select cp.nameoftheprogram,ac.collegename,ss.civilid,cc.coursecode,cc.coursename,cc.referencenumber,hh.academicyear,hh.year,hh.semesterid,hh.oldobtainedmarks,hh.newobtainedmarks,hh.createddate from univ_exam_studentexternaltheorymarkshistory hh
join student_student ss on ss.studentid=hh.studentid
join univ_exam_externaltheorymark etm on etm.externaltheorymarkid=hh.externaltheorymarkid
join courses_course cc on cc.courseid=etm.courseid
join courses_program cp on cp.programid=ss.program
join affiliation_college ac on ac.generatedinstituteid=ss.institutename
where hh.userid = 22881012




select * from student_student where civilid = '221010060032' --32845



select * from user_ where userid = 22881012