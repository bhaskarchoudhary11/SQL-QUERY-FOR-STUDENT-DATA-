﻿
---------------------------Reappear -------------------------
select
  cc.courseid,
  sr.reappearregistrationid,
  sps.studentid,
  cc.coursename,
  cc.coursecode,
  cc.referencenumber,
  ss.civilid,
  sps.reappearyear,
  sr.semesterid,
  ac.collegename,
  cp.nameoftheprogram
  from  student_progression_studentprogressionreappearsubjectsregistrat sr
  join student_progression_studentprogressionreappearregistration sps on sps.reappearregistrationid = sr.reappearregistrationid
  join student_student ss on ss.studentid = sps.studentid
  join courses_course cc on cc.courseid = sr.courseid
  join affiliation_college ac on ac.generatedinstituteid = ss.institutename
  join courses_program cp on cp.programid = ss.program
where
  sr.createdate >= '2023-04-01'
  and sr.createdate <= '2023-05-03'
  and ss.civilid = '212900230267'
  and sr.status= 'Approved'

  select * from student_progression_studentprogressionreappearsubjectsregistrat where reappearregistrationid = 34258
  


  

  select * from student_progression_studentprogressionreappearregistration limit 10



Select * from courses_course limit 10

-------------------------------------------------------------------------


----------------------------------------------------RE result-------------------------------------------



select c.collegename,p.nameoftheprogram,s.intakeyear,sem.semestername,s.civilid,s.studentidcardno,cc.coursecode,cc.referencenumber,cc.coursename from student_progression_courseprogression cp
join student_student s on s.studentid=cp.studentid
join courses_course cc on cc.courseid=cp.courseid
join courses_semester sem on sem.semesterid=cp.semester
join courses_program p on p.programid=cp.programid
join affiliation_college c on c.generatedinstituteid=s.institutename
where coursecompletionstatus ='RE' and s.civilid = '212900230267'
order by c.collegename,p.nameoftheprogram,s.intakeyear,sem.semestername,s.civilid,s.studentidcardno,cc.coursecode,cc.referencenumber,cc.coursename

select * from student_student where civilid = '212900230267'



-------------------------------------------------------------------------------------------------------------