﻿select cc.courseid,cc.coursecode,cc.referencenumber,cc.coursedescription,cc.coursename,cp.nameoftheprogram,ui.academicyear,ui.semesterid,ac.collegename,ui.externaltheorymarkid,his.oldobtainedmarks,his.newobtainedmarks,
ss.civilid,si.obtainedmarks
from univ_exam_externaltheorymark ui
join univ_exam_studentexternaltheorymarks si on si.externaltheorymarkid=ui.externaltheorymarkid
join student_student ss on ss.studentid=si.studentid
join courses_program cp on cp.programid=ss.program
join courses_course cc on cc.courseid=ui.courseid
left join affiliation_college ac on ac.generatedinstituteid=ss.institutename
left join univ_exam_studentexternaltheorymarkshistory his on his.studentexternaltheorymarksid=si.studentexternaltheorymarksid
where ui.academicyear in('2021-2022') and ui.semesterid=1 and ss.studentid  =27095 order by cc.courseid



select * from student_student where civilid ='211070090007'


select distinct  cen.examcentername,cen.examcentercode,sta.mobilenumber,sta.email,sta.employeename,cat.manpowercategory
from affiliation_manpowerallocation man
join affiliation_manpowerallocationstaffmapping manpo on manpo.manpowerallocationid=man.manpowerallocationid
join affiliation_exammanpowercategory cat on cat.exammanpowercategoryid=man.exammanpowercategoryid
join affiliation_staff sta on sta.staffid=manpo.staffid
join univ_exam_examcenter cen on cen.examcenterid=man.examcenterid
where cat.exammanpowercategoryid=1