﻿select o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursecode,c.referencenumber,c.coursename,s.intakeyear,s.civilid,s.fullname,se.resultcategory
from univ_exam_externaltheorymark et
join univ_exam_studentexternaltheorymarks se on se.externaltheorymarkid=et.externaltheorymarkid
join student_student s on s.studentid=se.studentid
join courses_course c on c.courseid=et.courseid
join courses_semester sem on sem.semesterid=et.semesterid
join organization_ o on o.organizationid=s.institutename
join courses_program p on p.programid=s.program
where et.academicyear='2020-2021' and et.year=3 and et.semesterid=5 and se.resultcategory='RLA'
order by o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursename,s.intakeyear,s.civilid,s.fullname

--2315   5th
--5186   3rd
--7809   1st

select o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursecode,c.referencenumber,c.coursename,s.intakeyear,s.civilid,s.fullname,se.resultcategory
from univ_exam_externaltheorymark et
join univ_exam_studentexternaltheorymarks se on se.externaltheorymarkid=et.externaltheorymarkid
join student_student s on s.studentid=se.studentid
join courses_course c on c.courseid=et.courseid
join courses_semester sem on sem.semesterid=et.semesterid
join organization_ o on o.organizationid=s.institutename
join courses_program p on p.programid=s.program
where et.academicyear='2021-2022' and et.year=2 and et.semesterid=3 and se.resultcategory='RLA'
order by o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursename,s.intakeyear,s.civilid,s.fullname

select o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursecode,c.referencenumber,c.coursename,s.intakeyear,s.civilid,s.fullname,se.resultcategory
from univ_exam_externaltheorymark et
join univ_exam_studentexternaltheorymarks se on se.externaltheorymarkid=et.externaltheorymarkid
join student_student s on s.studentid=se.studentid
join courses_course c on c.courseid=et.courseid
join courses_semester sem on sem.semesterid=et.semesterid
join organization_ o on o.organizationid=s.institutename
join courses_program p on p.programid=s.program
where et.academicyear='2022-2023' and et.year=1 and et.semesterid=1 and se.resultcategory='RLA'
order by o.name,p.nameoftheprogram,et.academicyear,et.year,sem.semestername,c.coursename,s.intakeyear,s.civilid,s.fullname