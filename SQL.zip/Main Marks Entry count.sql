﻿select
  distinct cp.nameoftheprogram,
  sc.courseid,
  cc.coursecode,
  cc.coursename,
  cc.referencenumber,
  sc.currentacademicyear,
  cp.programid,
  semesterintakeyearid,
  (
    select
      count(studentid)
    from
      student_progression_semesterprogression
    where
      currentacademicyear = 2022
      and semesterid = 1
      and confirmedprogramid = cp.programid
  ) as studentcount,
  (
    select
      count(studentid)
    from
      univ_exam_studentexternaltheorymarks ust
      join univ_exam_externaltheorymark ue on ue.externaltheorymarkid = ust.externaltheorymarkid
      and ue.courseid = sc.courseid
      and ue.semesterid = 1
      and ue.academicyear = '2022-2023'
      and ust.obtainedmarks > 0
      and ust.studentid in (
        select
          studentid
        from
          student_student
        where
          program = cp.programid
      )
  ) as markupdated,
  (
    select
      case when must = 't' then 'Mandatory' else 'Optional' end
    from
      courses_semesterintakeyearcourse
    where
      semesterintakeyearid = sc.semesterintakeyearid
      and courseid = sc.courseid
      and intakeyear = 2022
      and semesterid = 1
  ) as Exam_Type,
  md.valuename
from
  student_progression_courseprogression sc
  join courses_program cp on cp.programid = sc.programid
  join courses_course cc on cc.courseid = sc.courseid
  and cc.coursecategory in (553,563)
  join master_lookupvalue md on md.id_ :: text = cc.typeofcourse
where
  sc.currentacademicyear = 2022
  and semester = 1
group by
  sc.studentid,
  cp.nameoftheprogram,
  sc.courseid,
  cc.coursecode,
  cc.coursename,
  sc.currentacademicyear,
  cp.programid,
  cc.referencenumber,
  semesterintakeyearid,
  md.valuename


select * from courses_course limit 10

select * from master_lookupvalue where valuename in ('Theory', 'Both')