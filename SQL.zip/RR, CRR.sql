﻿--CRR

select distinct st.intakeyear,o.name ,c.nameoftheprogram,st.civilid,st.studentidcardno,st.fullname,cps.amountpaid,crp.paymentstatus,
crp.transactionnumber,to_char(crp.paymentinitiationdate,'dd-MM-yyyy')
from affiliation_crrpayment crp
join affiliation_crrpaidprogram cp on cp.crrpaymentid=crp.crrpaymentid
join affiliation_crrpaidstudents cps on cps.crrpaymentid=crp.crrpaymentid
inner join student_student st on st.studentid=cps.studentid
inner join courses_program c on c.programid=st.program
inner join  affiliation_college ac on ac.collegeid=crp.collegeid
join organization_ o on o.organizationid = ac.generatedinstituteid
order by intakeyear,name,nameoftheprogram

--RR

select st.intakeyear,o.name ,c.nameoftheprogram,st.civilid,st.studentidcardno,st.fullname,rr.amountpaid,rp.paymentstatus,
rp.transactionnumber,to_char(rp.paymentinitiationdate,'dd-MM-yyyy')
 from affiliation_rrpaidstudents rr inner join affiliation_rrpaidprogram cp on rr.rrpaymentid=cp.rrpaymentid
and cp.rrpaidprogramid=rr.rrpaidprogramid 
inner join affiliation_rrpayment rp on rp.rrpaymentid=cp.rrpaymentid
inner join student_student st on st.studentid=rr.studentid and st.program=cp.programid
inner join courses_program c on c.programid=st.program
inner join  affiliation_college ac on ac.collegeid=rp.collegeid
join organization_ o on o.organizationid = ac.generatedinstituteid
order by intakeyear,name,nameoftheprogram