﻿select ex.examcenterattendanceid,ac.collegename,cp.nameoftheprogram,stuex.semesterid,ss.intakeyear,cc.coursecode,cc.coursename,cc.coursedescription,cc.referencenumber,ss.civilid,ss.fullname,stuex.isumc,isabsent,
ex.examdate as "Examdate",cen.examcentercode
from affiliation_studentexamcenterattendance stuex
join student_student ss on ss.studentid=stuex.studentid
join affiliation_examcenterattendance ex on ex.examcenterattendanceid=stuex.examcenterattendanceid
join univ_exam_examcenter cen on cen.examcenterid=ex.examcenterid
join courses_course cc on cc.courseid=stuex.courseid
join affiliation_college ac on ac.generatedinstituteid=ss.institutename
join courses_program cp on cp.programid=ss.program
where ex.examdate > '2023-05-24 00:00:00'



select * from affiliation_studentexamcenterattendance limit 2