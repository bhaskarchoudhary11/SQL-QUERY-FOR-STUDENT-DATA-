﻿SELECT
siy.academicyear, cpm.nameoftheprogram AS "Program Name", sem.semestername,
crs.coursename AS "Subject Name", crs.coursecode AS "Subject Code",

 

round((cast((SUM(CASE WHEN crpr.coursecompletionstatus='Pass' THEN 1 ELSE 0 end) * 100) as decimal)/NULLIF(SUM(1),0)),2) AS "Pass Percentage",
round((cast((SUM(CASE WHEN crpr.coursecompletionstatus='RE' THEN 1 ELSE 0 end) * 100) as decimal)/NULLIF(SUM(1),0)),2) AS "Reappear Percentage",
round((cast((SUM(CASE WHEN crpr.coursecompletionstatus='A' THEN 1 ELSE 0 end) * 100) as decimal)/NULLIF(SUM(1),0)),2) AS "Absent Percentage"
FROM
student_progression_courseprogression crpr
INNER JOIN student_student std ON std.studentid = crpr.studentid
INNER JOIN courses_program cpm ON std.program = cpm.programid
INNER JOIN courses_institutewiseprogram iwp ON iwp.programid = cpm.programid
INNER JOIN courses_semesterintakeyear siy ON iwp.institutewiseprogramid = siy.institutewiseprogramid 
AND crpr.semesterintakeyearid = siy.semesterintakeyearid
INNER JOIN courses_course crs ON crpr.courseid = crs.courseid
join courses_semester sem on sem.semesterid=crpr.semester
INNER JOIN affiliation_college clg ON std.institutename=clg.generatedinstituteid

WHERE
  crpr.coursecompletionstatus IN ('Pass','RE','A')
AND crpr.active_=true
--AND std.isactive=true  
--AND std.quotaid=(SELECT quotaid FROM admission_management_quota WHERE quotaid = std.quotaid)
GROUP BY   siy.academicyear, cpm.nameoftheprogram,sem.semestername, crs.coursename, crs.coursecode
ORDER BY siy.academicyear, cpm.nameoftheprogram,sem.semestername, crs.coursename