﻿select distinct app.fullname,newfamilyid,memberid,fatherfullname,motherfullname,dob,app.mobilenumber,app.email,app.gender,cp.nameoftheprogram from 
admission_management_applicantpppdetails app
join admission_management_applicant ac on ac.applicantid =app.applicantid
join admission_management_application appli on appli.applicantid=app.applicantid
join courses_program cp on cp.programid=appli.appliedprogramid
where app.applicantid in (
select am.applicantid from admission_management_application  am
join admission_management_admissionconfiguration ac on ac.admissionconfigurationid =am.admissionconfigurationid where ac.intakeyear =2023 and applicationstatus in (0)
) 




select * from student_student where studentid in (52433,
52473
)



select * from student_student where civilid = '22128410059'