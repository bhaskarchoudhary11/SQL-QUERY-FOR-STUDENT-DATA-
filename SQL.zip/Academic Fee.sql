﻿select distinct fs.intakeyear,ss.civilid,ss.fullname,
(SELECT firstname from student_gaurdianpersonal  where studentid = ss.studentid and  
relationship = (SELECT id_ from master_lookupvalue  where valuename  ilike 'father' and companyid = companyid)limit 1) as fathername,
(SELECT firstname from student_gaurdianpersonal  where studentid = ss.studentid and  
relationship = (SELECT id_ from master_lookupvalue  where valuename  ilike 'mother' and companyid = companyid)limit 1) as mothername,q.quotaname,
nameoftheprogram,totalamounttobepaid,grandtotalpaidamount,year as Unpaidyear,
(case when paymentstatus='' then 'Unpaid' else paymentstatus end) ,
to_char(paymentstartdate,'dd-MM-yyyy')as paymentstartdate,to_char(paymentenddate,'dd-MM-yyyy') as paymentenddate
from feesmanagement_studentfeepayment sef 
inner join feesmanagement_feestructure fs on fs.feestructureid=sef.feestructureid  
inner join student_student ss on sef.studentid = ss.studentid
inner join courses_program cp on fs.programid = cp.programid 
inner join admission_management_quota q on ss.quotaid = q.quotaid
order by civilid,nameoftheprogram,paymentstatus
