﻿SELECT
  distinct ec.examcentercode,
  ec.examcentername,
  et.examdate,
  et.starttime,
  et.endtime,
  et.examinationslot,
  cc.coursecode,
  cc.coursename,
  cc.referencenumber,
  cp.semester,
  spspr.studentid,
  st.civilid
  --count(spspr.studentid)
FROM
  univ_exam_examtimetable et
  JOIN student_progression_courseprogression cp ON et.courseid = cp.courseid
  JOIN univ_exam_studentexamcenter sec ON sec.studentid = cp.studentid
  JOIN univ_exam_examcenter ec ON sec.examcenterid = ec.examcenterid
  JOIN courses_course cc ON cc.courseid = cp.courseid
  JOIN student_progression_studentprogressionreappearregistration spspr ON spspr.studentid = cp.studentid
  AND spspr.reappearyear = sec.reappearyear
  AND spspr.paymentstatus = 'Success'
  JOIN student_progression_studentprogressionreappearsubjectsregistrat spsprt ON spsprt.reappearregistrationid = spspr.reappearregistrationid
  AND spsprt.semesterid = sec.semesterid
  AND spsprt.status = 'Approved'
  AND spsprt.courseid = cp.courseid
  JOIN student_student st ON st.studentid = spspr.studentid
WHERE
  et.examdate BETWEEN '2023-05-25'
  AND '2023-07-31'
  AND et.isreappear = TRUE
  AND et.semesterid = sec.semesterid --AND sec.reappearmonth=spspr.reappearmonth
  --AND et.reappearmonth=sec.reappearmonth
  AND et.academicyear = sec.academicyear
  AND sec.examcenterid = ec.examcenterid
  AND sec.reappearyear = et.reappearyear
and spsprt.examtype='553'
  AND cp.semester = sec.semesterid and spspr.reappearyear=2024 --AND spspr.studentid=6780 
  --and ec.examcentercode = '2307_May 23'
 
ORDER BY
  et.examdate,
  et.examinationslot,
  cc.coursecode,
  cc.coursename,
  cc.referencenumber
  --cp.semester