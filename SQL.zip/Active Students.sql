﻿select distinct sm.intakeyear,oo.name,cp.nameoftheprogram,sm.civilid,sm.fullname
,(select semesterid from student_progression_semesterprogression where studentid =sm.studentid order by semesterid desc limit 1 ) as ongoingsem from student_student sm
join  student_progression_semesterprogression sec on sec.studentid =sm.studentid 
join organization_ oo on oo.organizationid= sm.institutename 
join courses_program cp on cp.programid =sm.program and sm.isactive =true and sm.studentid not in (
select st.studentid from student_student st 
join  student_progression_semesterprogression sm on sm.studentid =st.studentid 
join univ_exam_programlastsemesterconfiguration  usm on usm.lastsemprogramid =st.program  
where sm.semesterid =usm.lastsemester and sm.semesterstatus in ('RE','Pass','A') 
) order by sm.intakeyear,oo.name,cp.nameoftheprogram,sm.civilid,sm.fullname;



SELECT * FROM student_student LIMIT 10

--with parents name--
select ac.collegename,cp.nameoftheprogram, ss.intakeyear,ss.civilid,ss.studentidcardno,ss.fullname,ss.aadhaarnumber,ss.dateofbirth,lv.valuename,amq.quotaname,sa.mobile ,ss.intakeyear,cp.typeoftheprogram,
sg.firstname as "Father name",sgg.firstname as "Mother name"


from student_student ss 
join courses_program cp on cp.programid = ss.program
join master_lookupvalue lv on lv.id_=ss.gender
join admission_management_quota amq on amq.quotaid=ss.quotaid
join student_studentcurrentaddress sa on sa.studentid = ss.studentid
join affiliation_college ac on ac.generatedinstituteid= ss.institutename
join student_gaurdianpersonal sg on sg.studentid=ss.studentid and sg.relationship=36
join student_gaurdianpersonal sgg on sgg.studentid=ss.studentid and sgg.relationship=37
where ss.intakeyear in (2019,2020,2021,2022) 
limit 10
