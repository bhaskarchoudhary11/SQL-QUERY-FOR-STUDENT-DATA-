﻿select * from student_student where civilid = '221270230784'



select * from courses_course where coursecode='180-EL-203311'--7556

 

select * from courses_course where coursecode='180-PA-203311P'--7559

 

select collegename,generatedinstituteid from affiliation_college where generatedinstituteid in (
select instituteid from univ_exam_practicalmark where courseid=7577)

select * from univ_exam_practicalmark where courseid=7580;  ---sub
select * from univ_exam_practicalmark where courseid=7577; ---Main

 

select * from univ_exam_studentpracticalmarks where practicalmarkid in (
select practicalmarkid from univ_exam_practicalmark where courseid=7577)

 


update univ_exam_practicalmark set courseid=7556 where courseid=7559;