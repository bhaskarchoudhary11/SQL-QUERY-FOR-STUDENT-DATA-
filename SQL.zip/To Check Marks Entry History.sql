﻿select * from univ_exam_studentexternaltheorymarks where studentid = 5158

--4751


select * from univ_exam_studentexternaltheorymarkshistory where studentid = 32845 and externaltheorymarkid = 4751





select * from student_student where civilid = '191270250065' --32845



select * from user_ where userid = 22881012